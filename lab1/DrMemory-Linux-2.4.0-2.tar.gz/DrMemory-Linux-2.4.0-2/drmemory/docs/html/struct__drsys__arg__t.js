var struct__drsys__arg__t =
[
    [ "arg_name", "struct__drsys__arg__t.html#a91e5e2739f229d89cb9b9463f6d24000", null ],
    [ "containing_type", "struct__drsys__arg__t.html#aadd7be992ddd4ce19df321792501ae3a", null ],
    [ "drcontext", "struct__drsys__arg__t.html#a85e6af373eaf287bc9682ce219ec3dba", null ],
    [ "enum_name", "struct__drsys__arg__t.html#ad92b8d14723ed4cc2074a8c3248f8946", null ],
    [ "mc", "struct__drsys__arg__t.html#a0e6b704653ac9f1d26a7cd3ad77edeaa", null ],
    [ "mode", "struct__drsys__arg__t.html#ab0bf8c695e86fa59ffa1d89cd65ef86f", null ],
    [ "ordinal", "struct__drsys__arg__t.html#abc5ce057f70278ea43ba58df7832ebac", null ],
    [ "pre", "struct__drsys__arg__t.html#ae56e3779cd8026c5cd3789b820a52e08", null ],
    [ "reg", "struct__drsys__arg__t.html#a51d3fef5c9cf6cf3e73857c75ff0beab", null ],
    [ "size", "struct__drsys__arg__t.html#aa8b3d6943ba6c56e086c2fc27ee5e76b", null ],
    [ "start_addr", "struct__drsys__arg__t.html#adf024d889968a29418ee86bc7937371f", null ],
    [ "syscall", "struct__drsys__arg__t.html#ae3f960c74180d7c6190415de8f059812", null ],
    [ "sysnum", "struct__drsys__arg__t.html#a1c3f24ad8500fd5b75a5a30eb16542cc", null ],
    [ "type", "struct__drsys__arg__t.html#aab5603b90334df9c4db01551e9016d33", null ],
    [ "type_name", "struct__drsys__arg__t.html#a5ab733d51da42b803a590786a73a042d", null ],
    [ "valid", "struct__drsys__arg__t.html#a733489957e1151fa3616ce3c7342177b", null ],
    [ "value", "struct__drsys__arg__t.html#a31f22cd86d55c9e999aa700633553f35", null ],
    [ "value64", "struct__drsys__arg__t.html#a3e6ca2fd9ff8f263f91c973eb215c84f", null ]
];