var page_developers =
[
    [ "Contributing to Dr. Memory", "page_contribute.html", null ],
    [ "Building from Sources", "page_build.html", null ],
    [ "Updating the DynamoRIO Submodule", "page_submodule.html", null ],
    [ "Project Suggestions for Dr. Memory Contributors", "page_projects.html", null ],
    [ "New Release", "page_new_release.html", null ],
    [ "Test Suite", "page_test.html", null ],
    [ "Design Documents", "page_design_docs.html", "page_design_docs" ]
];