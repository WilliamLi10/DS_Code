var struct__drsys__options__t =
[
    [ "analyze_unknown_syscalls", "struct__drsys__options__t.html#a98bced7cd4296b8074f922cc529e9e3a", null ],
    [ "is_byte_addressable", "struct__drsys__options__t.html#af6e76fc688fc85e8a95858f2e9266e91", null ],
    [ "is_byte_defined", "struct__drsys__options__t.html#a7d6cea765d2366b00ebcbb1ae30280d0", null ],
    [ "is_byte_undefined", "struct__drsys__options__t.html#a8611264d4ac992a45a795c2b7c2af250", null ],
    [ "is_register_defined", "struct__drsys__options__t.html#a445d5480361a22cfdf063b523f5d654c", null ],
    [ "lookup_internal_symbol", "struct__drsys__options__t.html#a2ef1bc5d546d8e4888ca97596ca6df6c", null ],
    [ "skip_internal_tables", "struct__drsys__options__t.html#ae98bfa07c53b7d298fda30b7be617452", null ],
    [ "struct_size", "struct__drsys__options__t.html#ac35d3a3a7f5dd5f266b95d8bdb1d948d", null ],
    [ "syscall_driver", "struct__drsys__options__t.html#acf96eea8b757c1cf5cf9cc5ebf1dad54", null ],
    [ "syscall_dword_granularity", "struct__drsys__options__t.html#a8dafc6a6995f1c11438e200ab130ef6c", null ],
    [ "syscall_sentinels", "struct__drsys__options__t.html#a0903b4a6615e8f83fbe60a2211750675", null ],
    [ "sysnum_file", "struct__drsys__options__t.html#ab983f4031f8c4e4d67c3b6b6b70b09c6", null ],
    [ "verify_sysnums", "struct__drsys__options__t.html#a918698345d3cd7e63847afceb00401d3", null ]
];