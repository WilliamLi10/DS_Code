var page_install =
[
    [ "Installing on Linux", "page_install_linux.html", [
      [ "Installing", "page_install_linux.html#sec_linux_install", null ]
    ] ],
    [ "Installing on Mac", "page_install_macos.html", [
      [ "System Requirements", "page_install_macos.html#sec_macos_utils", null ],
      [ "Installing", "page_install_macos.html#sec_macos_install", null ]
    ] ],
    [ "Installing on Windows", "page_install_windows.html", [
      [ "System Install", "page_install_windows.html#sec_windows_system", null ],
      [ "Local Install", "page_install_windows.html#sec_windows_local", null ]
    ] ],
    [ "Installing on Android", "page_install_android.html", null ]
];