var searchData=
[
  ['release_20notes_20for_20version_202_2e4_2e0',['Release Notes for Version 2.4.0',['../page_release_notes.html',1,'']]],
  ['replaced_20routines',['Replaced Routines',['../page_replace.html',1,'page_reports']]],
  ['running_20dr_2e_20memory',['Running Dr. Memory',['../page_running.html',1,'']]]
];
