var searchData=
[
  ['preparing_20your_20application',['Preparing Your Application',['../page_prep.html',1,'']]],
  ['project_20suggestions_20for_20dr_2e_20memory_20contributors',['Project Suggestions for Dr. Memory Contributors',['../page_projects.html',1,'page_developers']]],
  ['pre',['pre',['../struct__drsys__arg__t.html#ae56e3779cd8026c5cd3789b820a52e08',1,'_drsys_arg_t']]]
];
