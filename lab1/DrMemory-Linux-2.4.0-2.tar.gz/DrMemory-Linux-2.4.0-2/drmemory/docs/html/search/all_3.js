var searchData=
[
  ['containing_5ftype',['containing_type',['../struct__drsys__arg__t.html#aadd7be992ddd4ce19df321792501ae3a',1,'_drsys_arg_t']]],
  ['chinese_20quickstart_20instructions',['Chinese Quickstart Instructions',['../page_chinese.html',1,'']]],
  ['contributing_20to_20dr_2e_20memory',['Contributing to Dr. Memory',['../page_contribute.html',1,'page_developers']]],
  ['code_20coverage',['Code Coverage',['../page_coverage.html',1,'']]]
];
