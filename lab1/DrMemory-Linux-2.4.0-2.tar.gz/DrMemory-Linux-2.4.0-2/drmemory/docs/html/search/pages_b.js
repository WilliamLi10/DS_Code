var searchData=
[
  ['new_20release',['New Release',['../page_new_release.html',1,'page_developers']]]
];
