var searchData=
[
  ['preparing_20your_20application',['Preparing Your Application',['../page_prep.html',1,'']]],
  ['project_20suggestions_20for_20dr_2e_20memory_20contributors',['Project Suggestions for Dr. Memory Contributors',['../page_projects.html',1,'page_developers']]]
];
