var searchData=
[
  ['license_20for_20dr_2e_20memory',['License for Dr. Memory',['../page_license.html',1,'']]],
  ['light_20mode',['Light Mode',['../page_light.html',1,'']]]
];
