var searchData=
[
  ['chinese_20quickstart_20instructions',['Chinese Quickstart Instructions',['../page_chinese.html',1,'']]],
  ['contributing_20to_20dr_2e_20memory',['Contributing to Dr. Memory',['../page_contribute.html',1,'page_developers']]],
  ['code_20coverage',['Code Coverage',['../page_coverage.html',1,'']]]
];
