var searchData=
[
  ['home',['Home',['../index.html',1,'']]],
  ['handle_20leaks',['Handle Leaks',['../page_handle.html',1,'page_types']]]
];
