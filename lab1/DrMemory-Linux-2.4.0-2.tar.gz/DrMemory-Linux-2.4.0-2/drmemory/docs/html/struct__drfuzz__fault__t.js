var struct__drfuzz__fault__t =
[
    [ "access_address", "struct__drfuzz__fault__t.html#a621eeceae7b2f2b36f682cbc932f4ef2", null ],
    [ "fault_code", "struct__drfuzz__fault__t.html#a574af8fc872cb64b40ffd3cda1051f95", null ],
    [ "fault_pc", "struct__drfuzz__fault__t.html#accdc2ec11bfd45f2be6ca6fee8ff088e", null ],
    [ "thread_id", "struct__drfuzz__fault__t.html#a2f15950b1d895e38862a28f3202aa586", null ],
    [ "user_data", "struct__drfuzz__fault__t.html#a4a922b5d3a0ea99e43e52fbfaa99217b", null ]
];