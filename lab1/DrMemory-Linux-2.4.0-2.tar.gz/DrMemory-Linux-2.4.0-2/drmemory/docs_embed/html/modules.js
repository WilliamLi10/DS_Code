[
    [ "Dr. Syscall: System Call Monitoring Extension", "group__drsyscall.html", {% include_relative group__drsyscall.js %} ],
    [ "Umbra: DynamoRIO Shadow Memory Extension", "group__umbra.html", {% include_relative group__umbra.js %} ],
    [ "Dr. Fuzz: DynamoRIO Fuzz Testing Extension", "group__drfuzz.html", {% include_relative group__drfuzz.js %} ],
    [ "Dr. SymCache: Symbol Lookup Cache Extension", "group__drsymcache.html", {% include_relative group__drsymcache.js %} ],
    [ "Dr. Memory Framework", "group__drmf.html", {% include_relative group__drmf.js %} ]
],