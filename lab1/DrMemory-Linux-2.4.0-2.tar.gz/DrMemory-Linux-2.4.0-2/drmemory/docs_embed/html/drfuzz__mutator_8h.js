[
    [ "drfuzz_mutator_feedback", "group__drfuzz.html#ga0ea9c74f3478668cd07d8b1c044bf0ef", null ],
    [ "drfuzz_mutator_get_current_value", "group__drfuzz.html#ga07598ca7995c00e8ad161e13c6dfeb0c", null ],
    [ "drfuzz_mutator_get_next_value", "group__drfuzz.html#gabd7fea3c737dfe947a1bdc36f2020f64", null ],
    [ "drfuzz_mutator_has_next_value", "group__drfuzz.html#gaf9f6297b2fdac546526b134f267c5bb8", null ],
    [ "drfuzz_mutator_start", "group__drfuzz.html#gaf41be888e69ea42ba4571e7693d3ac0e", null ],
    [ "drfuzz_mutator_stop", "group__drfuzz.html#ga0ba1cec3e7b1a1f7873933b93a5adb8d", null ]
],