[
    [ "DRMGR_PRIORITY_NAME_DRSYMCACHE", "group__drsymcache.html#gadc95919cd07bac508f721b4bc93e454a", null ],
    [ "DRMGR_PRIORITY_NAME_DRSYMCACHE_SAVE", "group__drsymcache.html#gadd1ab24936340d4f84a0fac0e0534cc6", [
      [ "DRMGR_PRIORITY_MODLOAD_DRSYMCACHE_READ", "group__drsymcache.html#gga99fb83031ce9923c84392b4e92f956b5acfb1d8a854df37dc441c21d369f96ad3", null ],
      [ "DRMGR_PRIORITY_MODLOAD_DRSYMCACHE_SAVE", "group__drsymcache.html#gga99fb83031ce9923c84392b4e92f956b5a5a2ca67cff95fa3d359b2aca49d94aa8", null ],
      [ "DRMGR_PRIORITY_MODUNLOAD_DRSYMCACHE", "group__drsymcache.html#gga99fb83031ce9923c84392b4e92f956b5a4e2b00bf43d9684380879406f4a3e623", null ]
    ] ],
    [ "drsymcache_add", "group__drsymcache.html#ga098117d857d04e45ec07ee6caa55f11d", null ],
    [ "drsymcache_exit", "group__drsymcache.html#gac93f61aab50f0b1e2da8c08d8108d3d6", null ],
    [ "drsymcache_free_lookup", "group__drsymcache.html#gaad3e71b21256e238628bdb689bcc8c1f", null ],
    [ "drsymcache_init", "group__drsymcache.html#gae20727ceefa9b26b5d9851b6dbae8a7b", null ],
    [ "drsymcache_is_initialized", "group__drsymcache.html#ga6ec0bad9bf523d04d0ba4defc5fd7ee1", null ],
    [ "drsymcache_lookup", "group__drsymcache.html#ga8370402f3a8d154889e5f5346158b328", null ],
    [ "drsymcache_module_has_debug_info", "group__drsymcache.html#gad528ee5a5889cd39d0ec0db323d7c3b3", null ],
    [ "drsymcache_module_is_cached", "group__drsymcache.html#ga11057a892bbfba83e5f7111f64d97085", null ],
    [ "drsymcache_module_save_symcache", "group__drsymcache.html#ga52c95b9bd8e0668534e39b55ff921d39", null ]
],