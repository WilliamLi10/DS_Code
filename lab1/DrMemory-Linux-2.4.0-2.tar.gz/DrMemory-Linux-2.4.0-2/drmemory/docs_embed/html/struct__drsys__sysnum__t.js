[
    [ "number", "struct__drsys__sysnum__t.html#a8bd88b8cf94452119fe0d0f62f80bf2b", null ],
    [ "secondary", "struct__drsys__sysnum__t.html#a2f38db14bafa6e26dff8fe8c4290a3a2", null ]
],